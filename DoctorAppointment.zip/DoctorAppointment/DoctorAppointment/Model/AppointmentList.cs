﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DoctorAppointment.Model
{
    [XmlRoot("WellnessHospital")]
    public class AppointmentList
    {

        private ObservableCollection<Appointment> bookedAppointmentsList;

        [XmlArray("AppointmentList")]
        [XmlArrayItem("Appointment")]
        public ObservableCollection<Appointment> BookedAppointmentsList { get => bookedAppointmentsList; set => bookedAppointmentsList = value; }

        public AppointmentList()
        {
            bookedAppointmentsList = new ObservableCollection<Appointment>();
        }


        public void Add(Appointment appointment)
        {
            bookedAppointmentsList.Add(appointment);
        }

        public void Remove(Appointment appointment)
        {
            bookedAppointmentsList.Remove(appointment);
        }


        public void Sort() // Sorting list using LINQ
        {
            var sortedList = from appointment in BookedAppointmentsList
                              orderby appointment.Id
                              select appointment;
            BookedAppointmentsList = new ObservableCollection<Appointment>();
            foreach (Appointment appointment in sortedList)
            {
                BookedAppointmentsList.Add(appointment);
            }
        }

        public int Count
        {
            get { return bookedAppointmentsList.Count; }
        }

        public void Clear()
        {
            bookedAppointmentsList.Clear();
        }

        public Appointment this[int i]
        {
            get { return bookedAppointmentsList[i]; }
            set { bookedAppointmentsList[i] = value; }
        }
    }
}
