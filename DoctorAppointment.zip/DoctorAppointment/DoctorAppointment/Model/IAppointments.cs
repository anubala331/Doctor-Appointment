﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public interface IAppointment : IComparable<Appointment>
    {
        uint Id { get; set; }
        DateTime Date { get; set; }
        string TimeStamp { get; set; }
        Patient Patient { get; set; }
        bool Attended { get; set; }

    }
}
