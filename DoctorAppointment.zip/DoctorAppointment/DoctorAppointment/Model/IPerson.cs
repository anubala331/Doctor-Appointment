﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public interface IPerson : IComparable<Doctor>
    {
        uint Id { get; set; }
        string Name { get; set; }
        uint Age { get; set; }
        decimal Height { get; set; }
        string Gender { get; set; }
    }
}
