﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public class Physician : Doctor
    {

        public override string CheckPatient()
        {
            return "General Check Up";
        }
        public override string SpecialistDiagnosis()
        {
            throw new NotImplementedException();
        }
    }
}
