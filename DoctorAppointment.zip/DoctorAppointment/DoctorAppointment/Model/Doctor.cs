﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DoctorAppointment.Model
{

    [XmlInclude(typeof(Physician)), XmlInclude(typeof(Cardiologist)), XmlInclude(typeof(Dentist)), XmlInclude(typeof(Gynecologist))]
    public abstract class Doctor : IPerson
    {
        private uint id;
        private string name;
        private uint age;
        private decimal height;
        private string gender;

        public uint Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public uint Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string Gender { get => gender; set => gender = value; }

        public virtual string CheckPatient()
        {
            return "Patient Checked";
        }

        public int CompareTo(Doctor obj)
        {
            return Name.CompareTo(obj.Name);
        }

        public abstract string SpecialistDiagnosis();
    }
}
