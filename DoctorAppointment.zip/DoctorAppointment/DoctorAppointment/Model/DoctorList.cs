﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DoctorAppointment.Model
{
    [XmlRoot("WellnessHospital")]
    [XmlInclude(typeof(Physician)), XmlInclude(typeof(Cardiologist)), XmlInclude(typeof(Dentist)), XmlInclude(typeof(Gynecologist))]
    public class DoctorList
    {
        private List<Doctor> doctorList = new List<Doctor>();

        [XmlArray("DoctorsList")]
        [XmlArrayItem("Docter")]
        public List<Doctor> DoctorsList { get => doctorList; set => doctorList = value; }

        public void Add(Doctor doctor)
        {
            doctorList.Add(doctor);
        }

        public void Remove(Doctor doctor)
        {
            doctorList.Remove(doctor);
        }

        public int Count
        {
            get { return doctorList.Count; }
        }

        public void Clear()
        {
            doctorList.Clear();
        }

        public Doctor this[int i]
        {
            get { return doctorList[i]; }
            set { doctorList[i] = value; }
        }
    }
}
