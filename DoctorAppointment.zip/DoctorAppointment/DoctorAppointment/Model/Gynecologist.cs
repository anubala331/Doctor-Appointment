﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public class Gynecologist : Doctor
    {

        public string CheckForInfection()
        {
            return " Infection Checked ";
        }
        public string PregnancyCheck()
        {
            return " Pregnancy Checked ";
        }

        public override string SpecialistDiagnosis()
        {
            string checkUps = CheckForInfection();

            return checkUps;
        }
    }
}
