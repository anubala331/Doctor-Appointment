﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public class Dentist : Doctor
    {

        public string TeethCleaning()
        {
            return " Teeth Cleaning ,";
        }

        public string RootCanel()
        {
            return " Teeth RootCanel ";
        }

        public override string SpecialistDiagnosis()
        {
            string checkUps = TeethCleaning();
            checkUps += RootCanel();

            return checkUps;
        }
    }
}
