﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public class Appointment : IAppointment
    {
        private uint id;
        private DateTime date;
        private string timeStamp;
        private Patient patient;
        private bool attended;
        private Doctor doctor;
        private string docType;


        public Appointment() {
            patient = new Patient();
        }

        public uint Id { get => id; set => id = value; }
        public string TimeStamp { get => timeStamp; set => timeStamp = value; }
        public bool Attended { get => attended; set => attended = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public DateTime Date { get => date; set => date = value; }
        public Doctor Doctor { get => doctor; set => doctor = value; }
        public string DateStr { get => convertDate(); }
        public string DocType { get => docType; set => docType = value; }

        public string convertDate()
        {
            return date.ToString("MM/dd/yyyy");
        }
        // Comparing the Dates
        public int CompareTo(Appointment other)
        {
            return this.date.CompareTo(other.date);
        }
    }
}
