﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorAppointment.Model
{
    public class Cardiologist : Doctor
    {
        public string HeartCheckUp()
        {
            return "Heart CheckUp ";
        }
        public string HeartSurgery()
        {
            return "Heart Surgery";
        }
        public override string SpecialistDiagnosis()
        {
            string checkUps = HeartCheckUp();
            return checkUps;
        }
    }
}
