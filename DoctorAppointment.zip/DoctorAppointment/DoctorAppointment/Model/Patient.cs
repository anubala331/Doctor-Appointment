﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DoctorAppointment.Model
{
    public  class Patient : IPerson
    {
        private uint id;
        private string name;
        private uint age;
        private decimal height;
        private string gender;
        private long phone;

        public string Name { get => name; set => name = value; }
        public uint Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string Gender { get => gender; set => gender = value; }
        public long Phone { get => phone; set => phone = value; }
        [XmlIgnore]
        public uint Id { get => id; set => id = value; }

        public int CompareTo(Doctor obj)
        {
            throw new NotImplementedException();
        }
    }
}
