﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DoctorAppointment.Rules
{
    class AgeInRangeRule :ValidationRule
    {
        uint min;
        uint max;

        public uint Min { get => min; set => min = value; }
        public uint Max { get => max; set => max = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {

            uint number;
            if (!uint.TryParse((string)value, out number))
            {
                return new ValidationResult(false,
                    "Invalid Data Type");
            }
            if (number < min || number > max)
            {
                return new ValidationResult(false,
                    $"Out of range ({Min}-{Max})");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }
}
