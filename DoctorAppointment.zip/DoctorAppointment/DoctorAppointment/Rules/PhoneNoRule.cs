﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DoctorAppointment.Rules
{
    class PhoneNoRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            long card;
            if (!long.TryParse(value.ToString(), out card))
            {
                return new ValidationResult(false, "Numeric Value only");

            }
            if (value.ToString().Length != 10)
            {
                return new ValidationResult(false, "Should be 10 Digit");
            }
            else
            {
                return ValidationResult.ValidResult;
            }

        }
    }
}
