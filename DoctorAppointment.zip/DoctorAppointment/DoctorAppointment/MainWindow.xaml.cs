﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DoctorAppointment.Model;


namespace DoctorAppointment
{
    
    public partial class MainWindow : Window
    {
        private Operations operations;
        private Appointment appointment = new Appointment();
        private AppointmentList appointmentList;
        private AppointmentList unsavedList;
        private AppointmentList filterAppointmentList;
        private DoctorList doctors;
        private uint currentAppointmentId = 1;
        private bool isEditMode  = false;
        private List<string> availableSlots = new List<string>();
        private int selectedDoctorKey;
        private int filteredKey = -1;
        public MainWindow()
        {
            InitializeComponent();
            appointmentDate.SelectedDate = DateTime.Now.Date;
            appointmentDate.DisplayDateStart = DateTime.Today;
            operations = new Operations();
            appointmentList = new AppointmentList();
            unsavedList = new AppointmentList();
            filterAppointmentList = new AppointmentList();
            doctors = new DoctorList();
            SetDoctors();
            SetFilterBox();
            GetLastIndex();
            DataContext = this;
        }

        // Different List Instance to change grid Binding source as per user selection/App State
        public Appointment Appointment { get => appointment; set => appointment = value; }
        public DoctorList Doctors { get => doctors; set => doctors = value; }
        public AppointmentList AppointmentList { get => appointmentList; set => appointmentList = value; }
        public AppointmentList UnsavedList { get => unsavedList; set => unsavedList = value; }

        private void GetLastIndex() // Reading the Saved List and Getting the last Appointment ID.
        {
            appointmentList = operations.ReadAppointmentsFromXML();
            if (appointmentList.Count > 0)
            {
                int lastindex = appointmentList.Count - 1;
                currentAppointmentId = appointmentList[lastindex].Id + 1;
                Console.WriteLine("Current ID: {0}", currentAppointmentId);
            }
        }

        private void SetDoctors() // Setting Doctors ComboBox
        {
            doctors = operations.ReadDoctorsFromXML();
            doctorBox.ItemsSource = operations.DoctorTypes();
            doctorBox.DisplayMemberPath = "Value";
        }

        // Event Handler for Docter Combobox Value Change
        private void doctorBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedDoctorKey = doctorBox.SelectedIndex;
            UpdateTimeSlots(operations.ReadAppointmentsFromXML());

        }

        // Funtion for Diaplay Selected Docter's Name. 
        private void DisplayDoctorName(object sender, RoutedEventArgs e)
        {
            doctorName.Content = doctors[selectedDoctorKey].Name;
        }

        // Event Handler for Adding Appointments(To list and Grid)
        private void bookAppointment_Click(object sender, RoutedEventArgs e)
        {
            //validate input fields
            bool allValid = validateData();

            // Check for empty data and if window has any invalid Validation Rule
            if (allValid && !Validation.GetHasError(nameInput) && !Validation.GetHasError(ageInput) && !Validation.GetHasError(heightInput) && !Validation.GetHasError(phoneNumber))
            {
                appointment.Id = currentAppointmentId;
                appointment.Date = (DateTime)appointmentDate.SelectedDate;
                appointment.TimeStamp = timeSlotBox.Text;
                appointment.Attended = false;
                appointment.Doctor = doctors[selectedDoctorKey];
                Appointment newAppointment = operations.BuildAppointmentObj(appointment);
                unsavedList.Add(newAppointment);
                appointmentGrid.ItemsSource = unsavedList.BookedAppointmentsList;
                infoLabel.Content = "Please Save the data to avoid Data Lost";
                currentAppointmentId++;
                resetForm();
            }
        }

        // Event Handler for Saved Appointments To File
        private void saveData_Click(object sender, RoutedEventArgs e)
        {
            // Adding data to main List insatnce if there is Any Unsaved Data.
            if (unsavedList.Count > 0)
            {
                foreach(Appointment app in unsavedList.BookedAppointmentsList)
                {
                    appointmentList.Add(app);
                }
                unsavedList.Clear();
                infoLabel.Content = "Data Saved ! Press View to Fetch Data";
            }
            operations.WriteAppoinmentToXML(appointmentList);
           
        }

        // Event Handler to Fetched AppointmentList from File
        private void ViewAppointment_Click(object sender, RoutedEventArgs e)
        {
            AppointmentList = operations.ReadAppointmentsFromXML();
            appointmentList.Sort();
            appointmentGrid.ItemsSource = appointmentList.BookedAppointmentsList;
            filterBox.SelectedIndex = -1;
            searchInfo.Content = appointmentGrid.Items.Count == 0 ? "No Data Found" : string.Format("Total : {0}", appointmentGrid.Items.Count);
            if (infoLabel.Content.ToString().Contains("!"))
            {
                infoLabel.Content = string.Empty;
            }
        }

        // Event Handler for Radio button value change
        private void genderChanged(object sender, RoutedEventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            switch (rb.Name)
            {
                case "male":
                    appointment.Patient.Gender = "Male";
                    break;
                case "female":
                    appointment.Patient.Gender = "Female";
                    break;
                default:
                    break;
            }

        }

        // Function To Validate Against Empty fields (Untouched TestBox)
        private bool validateData()
        {
            bool flag = true;
            if ((nameInput.Text == string.Empty) || (ageInput.Text == string.Empty) || (heightInput.Text == string.Empty) || (phoneNumber.Text == string.Empty) || (appointment.Patient.Name == null) || (appointment.Patient.Name.Length < 0) || (appointment.Patient.Age == 0) || (appointment.Patient.Height == 0m) || (appointment.Patient.Phone == 0))
            {
                infoText.Content = "❗ Please Fill All Valid Data";
                flag = false;
            }
            return flag;
        }


        // Dynamically changeing(Add/Remove) Timeslots combobox as per selected docter and its availability
        public void UpdateTimeSlots(AppointmentList fileList)
        {
            availableSlots.Clear();
            availableSlots.Add("09:00 AM");
            availableSlots.Add("10:00 AM");
            availableSlots.Add("11:00 AM");
            availableSlots.Add("12:00 PM");
            availableSlots.Add("02:00 PM");
            availableSlots.Add("03:00 PM");
            availableSlots.Add("04:00 PM");
            availableSlots.Add("05:00 PM");
        
            if (fileList != null)
            {
                var filterList = from appointment in fileList.BookedAppointmentsList
                                 where appointment.Doctor.Id == selectedDoctorKey + 1
                                 select appointment;
                foreach (Appointment app in filterList)
                {
                    if (app.Doctor.Id == selectedDoctorKey+1)
                    {
                        if (availableSlots.Contains(app.TimeStamp))
                        {
                            availableSlots.Remove(app.TimeStamp);
                        }
                    }
                }
            }
            if (unsavedList.Count > 0)
            {
                foreach (Appointment app in unsavedList.BookedAppointmentsList)
                {
                    if (app.Doctor.Id == selectedDoctorKey + 1)
                    {
                        if (availableSlots.Contains(app.TimeStamp))
                        {
                            availableSlots.Remove(app.TimeStamp);
                        }
                    }
                }
            }
            timeSlotBox.ItemsSource = availableSlots;
            timeSlotBox.Items.Refresh();
            timeSlotBox.SelectedIndex = 0;
            if (timeSlotBox.Items.Count <= 0)
            {
                bookAppointment.IsEnabled = false;
                bookAppointment.ToolTip = "No Slot Available";
            }
        }
        // Function for Search by Patient Name
        // Here, .Contains() function of string id used, so the search result would include "Jack" and "Mac" 
        // when Searched for "ac".
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            filterAppointmentList.Clear();
            string searchValue = searchInput.Text;
            var query = from appointment in appointmentList.BookedAppointmentsList
                        where appointment.Patient.Name.ToLower().Contains(searchValue.ToLower())
                        select appointment;
            foreach (Appointment appointment in query)
            {
                filterAppointmentList.BookedAppointmentsList.Add(appointment);
            }
            appointmentGrid.ItemsSource = filterAppointmentList.BookedAppointmentsList;
            searchInfo.Content = query.Count()==0 ? "No Data Found" : string.Format("Total : {0}", query.Count());
        }

        // Function to check search input length, if zero then
        // it will change the Datagrid source back to main(All) List
        private void CheckLength(object sender, TextChangedEventArgs e)
        {
            if (searchInput.Text == null || searchInput.Text.Length == 0)
            {
                filterAppointmentList.Clear();
                searchInfo.Content = string.Empty;
                appointmentGrid.ItemsSource = appointmentList.BookedAppointmentsList;
                filterBox.SelectedIndex = -1;
            }
        }
        // Function to delete the Selected Row after user Conformation.
        private void DeleteRow(object sender, RoutedEventArgs e)
        {
            //uint deleteId = (appointmentGrid.SelectedItem as Appointment).Id;
            MessageBoxResult messageBoxResult = MessageBox.Show("Are you Sure to delete ?", "Delete Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                appointmentList.Remove(appointmentGrid.SelectedItem as Appointment);
                operations.WriteAppoinmentToXML(appointmentList);
            }
        }

        // Function to reset the Values
        private void resetForm()
        {
            timeSlotBox.SelectedIndex = 0;
            doctorBox.SelectedIndex = 0;
            // clearing All fields
            phoneNumber.Text = string.Empty;
            nameInput.Text = string.Empty;
            ageInput.Text = string.Empty;
            heightInput.Text = string.Empty;
            searchInput.Text = string.Empty;
            male.IsChecked = true;
            female.IsChecked = false;
            infoText.Content = string.Empty;
            UpdateTimeSlots(null);
        }

        // Fuction to Filter the datagrid list as per selected option in filterBox
        private void filterBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (filterBox.SelectedIndex != -1)
            {
                filterAppointmentList.Clear();
                filterAppointmentList = operations.ProcessFiltering(filterBox.SelectedIndex, appointmentList);
                searchInfo.Content = filterAppointmentList.Count == 0 ? "No Data Found" : string.Format("Total : {0}", filterAppointmentList.Count);
                appointmentGrid.ItemsSource = filterAppointmentList.BookedAppointmentsList;
                filteredKey = filterBox.SelectedIndex;
            }
        }

        // Fuction to Enter Edit mode with the selected row Data of datagrid.
        private void editRow(object sender, RoutedEventArgs e)
        {
            if (unsavedList.Count <= 0)
            {
                isEditMode = true;
                ToggleButtons();
                Appointment appointment = appointmentGrid.SelectedItem as Appointment;
                appointmentDate.SelectedDate = appointment.Date;
                timeSlotBox.SelectedItem = appointment.TimeStamp;
                doctorBox.SelectedIndex = (int)appointment.Doctor.Id - 1;
                nameInput.Text = appointment.Patient.Name;
                ageInput.Text = appointment.Patient.Age.ToString();
                heightInput.Text = appointment.Patient.Height.ToString();
                phoneNumber.Text = appointment.Patient.Phone.ToString();
                if (appointment.Patient.Gender.Equals("Male"))
                {
                    male.IsChecked = true;
                }
                else
                {
                    female.IsChecked = true;
                }
                if (appointment.Attended == true)
                {
                    statusCheckBox.IsChecked = true;
                }
                timeSlotBox.Items.Refresh();
                doctorBox.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please Save the Data in order to Edit", "Unsaved Data Found");
            }
        }

        // Fuction to Update the selected row Data of datagrid in edit Mode.
        private void UpdateRow_Click(object sender, RoutedEventArgs e)
        {
            Appointment oldAppointment = appointmentGrid.SelectedItem as Appointment;
            
            if (!Validation.GetHasError(nameInput) && !Validation.GetHasError(ageInput) && !Validation.GetHasError(heightInput) && !Validation.GetHasError(phoneNumber))
            {
                appointmentList.Remove(oldAppointment);
                appointment.Id = oldAppointment.Id;
                appointment.Date = (DateTime)appointmentDate.SelectedDate;
                appointment.TimeStamp = timeSlotBox.Text;
                appointment.Doctor = doctors[selectedDoctorKey];
                appointment.Patient.Name = nameInput.Text;
                // Used Parse() as the Validation Rules will confirm the right Datatype
                appointment.Patient.Age = uint.Parse(ageInput.Text);
                appointment.Patient.Height = decimal.Parse(heightInput.Text);
                appointment.Patient.Phone = long.Parse(phoneNumber.Text);
                Appointment updatedAppointment = operations.BuildAppointmentObj(appointment);
                appointmentList.Add(updatedAppointment);
                operations.WriteAppoinmentToXML(appointmentList);
                infoLabel.Content = "Data Updated!";
                appointmentList.Sort();
                appointmentGrid.ItemsSource = appointmentList.BookedAppointmentsList;
                appointmentGrid.Items.Refresh();
                cancelEdit_Click(sender, e);
            }
            else{
                infoText.Content = "! Please Fill All Valid Data";
            }
        }

        // Function to handle cancel event in EditMode
        private void cancelEdit_Click(object sender, RoutedEventArgs e)
        {
            resetForm();
            isEditMode = false;
            ToggleButtons();
        }

        // Function to Toggle controls to Enter/Exit Edit mode.
        private void ToggleButtons()
        {
            if (isEditMode)
            {
                appointmentGrid.IsEnabled = false;
                ViewAppointment.IsEnabled = false;
                saveData.IsEnabled = false;
                bookAppointment.IsEnabled = false;
                ClearBtn.IsEnabled = false;
                searchInput.IsEnabled = false;
                SearchBtn.IsEnabled = false;
                filterBox.IsEnabled = false;
                statusCheckBox.IsEnabled = true;
                cancelEdit.Visibility = Visibility.Visible;
                updateRow.Visibility = Visibility.Visible;
            }
            else
            {
                appointmentGrid.IsEnabled = true;
                ViewAppointment.IsEnabled = true;
                saveData.IsEnabled = true;
                bookAppointment.IsEnabled = true;
                searchInput.IsEnabled = true;
                SearchBtn.IsEnabled = true;
                filterBox.IsEnabled = true;
                ClearBtn.IsEnabled = true;
                statusCheckBox.IsChecked = false;
                statusCheckBox.IsEnabled = false;
                cancelEdit.Visibility = Visibility.Hidden;
                updateRow.Visibility = Visibility.Hidden;
            }
        }
        // Function to handle data Change of checkBox for Appointment Status
        private void statusCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (statusCheckBox.IsChecked == true)
            {
                display.Visibility = Visibility.Visible;
                appointment.Attended = true;
                if (Doctors[selectedDoctorKey].GetType() != typeof(Physician)) {
                    display.Content = Doctors[selectedDoctorKey].CheckPatient() +" : "+
                                      Doctors[selectedDoctorKey].SpecialistDiagnosis();
                }
                else {
                    display.Content = Doctors[selectedDoctorKey].CheckPatient();
               }
            }
            else
            {
                display.Visibility = Visibility.Hidden;
                appointment.Attended = false;
                display.Content = string.Empty;
            }
        }
        // List to bind with FiterBox options
        private void SetFilterBox()
        {
            List<string> filterOptions = new List<string>();
            filterOptions.Add("By Physician");
            filterOptions.Add("By Dentists");
            filterOptions.Add("By Male");
            filterOptions.Add("By Female");
            filterOptions.Add("Attended Only");
            filterOptions.Add("Unattended Only");
            filterBox.ItemsSource = filterOptions;
            filterBox.SelectedIndex = -1;
        }

        // Function to handle clear btn event (Clears Grid Data and filter options)
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            searchInput.Text = string.Empty;
            searchInfo.Content = string.Empty;
            appointmentGrid.ItemsSource = unsavedList.BookedAppointmentsList;
            filterBox.SelectedIndex = -1;

        }
    }
}
