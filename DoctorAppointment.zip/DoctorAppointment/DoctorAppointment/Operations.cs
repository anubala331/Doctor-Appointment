﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using DoctorAppointment.Model;

namespace DoctorAppointment
{
    // This Class is to Manage App File Opreations and Data Initilization 
    class Operations
    {
        string AppointmentFile;
        string DoctorsFile;

        public Operations()
        {
            AppointmentFile = "Appointments.xml";
            DoctorsFile = "Docters.xml";

            // Fuction to save Docters list in Doctor.xml only if the file doesnt Exixts
            if (!File.Exists(DoctorsFile))
            {
                SetDoctorsList();
            }

        }
        // Function to Read Data from Doctors XML File
        public DoctorList ReadDoctorsFromXML()
        {
            DoctorList allDoctors = new DoctorList();
            StreamReader reader = null;
            if (File.Exists(DoctorsFile))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(DoctorList));
                    reader = new StreamReader(DoctorsFile);
                    allDoctors = (DoctorList)serializer.Deserialize(reader);
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }
            else
            {
                Console.WriteLine("File Does Not Exists");
            }

            return allDoctors;
        }
        // Function to write into Doctor XML File
        public void WriteDoctorsToXML(DoctorList docters)
        {

            TextWriter writer = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(DoctorList));
                writer = new StreamWriter(DoctorsFile);
                serializer.Serialize(writer, docters);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }

        // Function to Write Data to Appointment XML File
        public void WriteAppoinmentToXML(AppointmentList appointments)
        {
            TextWriter writer = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                writer = new StreamWriter(AppointmentFile);
                serializer.Serialize(writer, appointments);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }

        // Function to Read Data from Appointment XML File
        public AppointmentList ReadAppointmentsFromXML()
        {
            AppointmentList allAppointments = new AppointmentList();
            if (File.Exists(AppointmentFile))
            {
               
                StreamReader reader = null;
                if (File.Exists(AppointmentFile))
                {
                    try
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                        reader = new StreamReader(AppointmentFile);
                        allAppointments = (AppointmentList)serializer.Deserialize(reader);
                    }
                    catch (IOException e)
                    {
                        Console.WriteLine(e.ToString());
                    }
                    finally
                    {
                        if (reader != null)
                        {
                            reader.Close();
                        }
                    }
                }
                else
                {
                    Console.WriteLine("File Does Not Exists");
                }
                allAppointments.Sort();
            }
            return allAppointments;
        }

        public AppointmentList ProcessFiltering(int selectedIndex, AppointmentList appointmentList)
        {
            AppointmentList filterList = new AppointmentList();
            IEnumerable<Appointment> query = null;
            switch (selectedIndex)
            {
                case 0:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where appointment.Doctor.Id == 1
                            select appointment;
                    break;
                case 1:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where appointment.Doctor.Id == 3
                            select appointment;
                    break;
                case 2:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where appointment.Patient.Gender.Equals("Male")
                            select appointment;
                    break;
                case 3:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where appointment.Patient.Gender.Equals("Female")
                            select appointment;
                    break;
                case 4:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where appointment.Attended
                            select appointment;
                    break;
                case 5:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            where !appointment.Attended
                            select appointment;
                    break;
                default:
                    query = from appointment in appointmentList.BookedAppointmentsList
                            select appointment;
                    break;
            }
            foreach (Appointment appointment in query)
            {
                filterList.BookedAppointmentsList.Add(appointment);
            }
            return filterList;

        }

       

        public Dictionary<int, string> DoctorTypes()
        {
            Dictionary<int,string> doctorTypes = new Dictionary<int, string>();
            doctorTypes.Add(1,"Physician");
            doctorTypes.Add(2,"Cardiologist");
            doctorTypes.Add(3,"Dentist");
            doctorTypes.Add(4,"Gynecologist");

            return doctorTypes;
        }

        // Function To set Doctors List
        private void SetDoctorsList()
        {
            DoctorList docterlist = new DoctorList();
            docterlist.DoctorsList = new List<Doctor>();

            Physician physician = new Physician() { Id = 1, Name = "Dr. Anna Jock", Age = 26, Height = 5.2m, Gender = "Female" };
            Cardiologist cardiologist = new Cardiologist() { Id = 2, Name = "Dr. Hell Mirre", Age = 51, Height = 6.2m, Gender = "Female" };
            Dentist dentist = new Dentist() { Id = 3, Name = "Dr. Jaford lue", Age = 43, Height = 6.23m, Gender = "Male" };
            Gynecologist gynecologist = new Gynecologist() { Id = 4, Name = "Dr. Robert Mac", Age = 32, Height = 5.1m, Gender = "Male" };

            docterlist.DoctorsList.Add(physician);
            docterlist.DoctorsList.Add(cardiologist);
            docterlist.DoctorsList.Add(dentist);
            docterlist.DoctorsList.Add(gynecologist);

            WriteDoctorsToXML(docterlist);
        }
        //Function to build new instance of Appointment Object
        public Appointment BuildAppointmentObj(Appointment appointment)
        {
            Appointment newAppointment = new Appointment();
            newAppointment.Id = appointment.Id;
            newAppointment.Date = appointment.Date;
            newAppointment.TimeStamp = appointment.TimeStamp;
            newAppointment.Attended = false;
            newAppointment.Doctor = appointment.Doctor;
            newAppointment.Patient.Name = appointment.Patient.Name;
            newAppointment.Patient.Age = appointment.Patient.Age;
            newAppointment.Patient.Height = appointment.Patient.Height;
            newAppointment.Patient.Phone = appointment.Patient.Phone;
            newAppointment.Patient.Gender = appointment.Patient.Gender;
            newAppointment.Attended = appointment.Attended;
            newAppointment.DocType = appointment.Doctor.GetType().ToString().Split('.')[2];

            return newAppointment;
        }
    }
}
